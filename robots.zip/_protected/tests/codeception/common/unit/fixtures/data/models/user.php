<?php

return [
    [
        // this user is active and is member of the site
        'username' => 'member',
        'email' => 'member@example.com',
        'auth_key' => 'sjXnhU0Dpku3vZb3tTqxgtNBXUSOTLLU',
        // password is : member123
        'password_hash' => '$2y$13$4UkVY65btY8.uFsylJjq8O./fkoDJGQPASKOSW4.3D7RcbT8pvksm',
        'password_reset_token' => 'geGUnapFHpJWdztNKS4nj4Eb404Q1il1_1412606182',
        'status' => 10,
        'created_at' => '1412606129',
        'updated_at' => '1412606129',
    ],
    [
        // this user has not activated his account
        'username' => 'tester',
        'email' => 'tester@example.com',
        'auth_key' => 'AxCA1v9zj3183w1bttOIcsGGrvrwkm-u',
        // password is : test123
        'password_hash' => '$2y$13$L7u5zjs0hMHVuMWaJzt2MuOvsgpkpEqIW0ir9pcMAeK16zDPoHmJu',
        'password_reset_token' => 'OZdsAZ6RgiYbe08y8DOAwfUo6bnJvfed_1412601762',
        'status' => 1,
        'created_at' => '1412606129',
        'updated_at' => '1412606129',
    ],
];

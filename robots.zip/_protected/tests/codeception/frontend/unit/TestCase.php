<?php
namespace tests\codeception\frontend\unit;

/**
 * Class TestCase
 * 
 * @package tests\codeception\frontend\unit
 */
class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@tests/codeception/config/frontend/unit.php';
}

<?php

return [
    '{attribute} cannot be blank.' => '{attribute} não pode estar vazio.',
    'The verification code is incorrect.' => 'O código de verificação está incorrecto.',
    'Home' => 'Início',
    'You are not allowed to perform this action.' => 'Não está autorizado a executar esta acção.'
];

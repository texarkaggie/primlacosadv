<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Service */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Services'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="service-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'category_id',
            'sku',
            'title_en',
            'title_pt',
            'summary_en:ntext',
            'summary_pt:ntext',
            'description_en:ntext',
            'description_pt:ntext',
            'availability_en:ntext',
            'availability_pt:ntext',
            'price',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>

<?php
use frontend\assets\AppAsset;
use frontend\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use yii\helpers\Url;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3"></script>
    <?php $this->head() ?>
</head>
<body>
    <?php $this->beginBody() ?>
    <div class="wrap">
        <?php
            NavBar::begin([
                'brandLabel' => null,
                'brandUrl' => null,
                'options' => [
                    'class' => 'navbar-default',
                ],
            ]);

            // everyone can see Home page
            $menuItems[] = ['label' => Yii::t('app', 'HOME'), 'url' => ['/site/index']];
            
            if (Yii::$app->user->can('admin')) {
                $menuItems[] = ['label' => Yii::t('app', 'SERVICES'), 'url' => ['/service/index']];
                $menuItems[] = ['label' => Yii::t('app', 'PUBLICATIONS'), 'url' => ['/publication/index']];
                $menuItems[] = ['label' => Yii::t('app', 'PARTNERSHIPS'), 'url' => ['/partner/index']];
                $menuItems[] = ['label' => Yii::t('app', 'ABOUT US'), 'items' =>  [
                                    ['label' => Yii::t('app', 'INFO'), 'url' => ['/about/view', 'id' => 1]],
                                    ['label' => Yii::t('app', 'GALLERY'), 'url' => ['/gallery/view', 'id' => 1]],
                ]];
            }
            
            $menuItems[] = ['label' => Yii::t('app', 'CONTACTS'), 'url' => ['/contact/index']];
            
            echo Nav::widget([
                'options' => ['class' => 'navbar-nav navbar-right'],
                'items' => $menuItems,
            ]);
            NavBar::end();
        ?>
        
        <?php if(Url::current()== Url::home().'site/index'){?>           

            
        <div style="border-bottom-left-radius: 50% 46px; border-bottom-right-radius: 50% 46px; overflow: hidden;">
            <?= Html::img(Yii::getAlias('@uploads').'/images/slide02.jpg', ['style'=>'width: 100%;']); ?>
        </div>

            
        <?php } ?>
        
        <div class="container">
        <?= Breadcrumbs::widget([
            'homeLink'=>['label' => Yii::t('app', 'Home'), 'url' => ['site/index']],
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
        <?= $content ?>
        </div>
    </div>

    <?php if(Url::current()== Url::home().'contact/index'){?>    
        <footer class="contact-footer">
    <?php }else{ ?>    
        <footer class="footer">
    <?php }?>        
        <div class="container">
            <p class="pull-left">&nbsp;</p>
            <p class="pull-right">&copy; <?= Yii::t('app', Yii::$app->name) ?> <?= date('Y') ?></p>
        </div>
    </footer>

    <?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>

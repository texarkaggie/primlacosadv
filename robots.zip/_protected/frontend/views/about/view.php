<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\About */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'About Us'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="about-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'name_en',
            'name_pt',
            'intro_en:ntext',
            'intro_pt:ntext',
            'content_en:ntext',
            'content_pt:ntext',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>

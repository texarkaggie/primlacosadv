<?php

/* @var $this yii\web\View */
$this->title = Yii::t('app', Yii::$app->name);
?>
<div class="site-index">


    <div class="body-content">

        <div class="row">
            <div class="col-lg-2">
                <h3>Serviços</h3>
                <ul>
                    <li><a href="">Serviços 1</a></li>
                    <li>Serviços 2</li>
                    <li>Serviços 3</li>
                    <li>Serviços 4</li>
                    <li>Serviços 5</li>
                </ul>
                <h3>Cursos</h3>
                <ul>
                    <li><a href="">Cursos 1</a></li>
                    <li>Cursos 2</li>
                    <li>Cursos 3</li>
                    <li>Cursos 4</li>
                    <li>Cursos 5</li>
                </ul>
            </div>
            <div class="col-lg-10">
                
                    <h3>&nbsp</h3>
                    <div class="jumbotron">
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                    
                  
            </div>
        </div>

    </div>
</div>


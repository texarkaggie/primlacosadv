<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = Yii::t('app', Yii::$app->name);
?>
<div class="site-index">
    <div class="body-content">
        <div class="row">
            <div class="col-lg-4" style="text-align: center;">
                <div>
                    <?= Html::img(Yii::getAlias('@uploads').'/images/logo01.jpg', ['style'=>'width: 70%;']); ?>
                    <p style="font-family: SegoePrint; font-size: 17pt; font-weight: bold; color: #07a690; padding-top: 20px;">Espaço para Mães e Bebés</p>
                </div>
                <div style="padding: 5% 20%">        
                    <p style="margin: 10px 0;">Site em construção...</p>
                    <p style="margin: 10px 0;">Prometemos ser breves.</p>
                    <p style="margin: 10px 0;">Até lá pode seguir-nos nas redes sociais</p>
                    <div class="socials">
                        <a href="#"></a>
                        <a href="#"></a>
                        <a href="https://www.facebook.com/primeiroslacos" target="_blank"></a>            
                    </div>
                </div>
            </div>
            <div class="col-lg-8" style="text-align: center;">                
                    <?= Html::img(Yii::getAlias('@uploads').'/images/promo.jpg', ['style'=>'width: 100%;']); ?>                  
            </div>
        </div>
    </div>
</div>

